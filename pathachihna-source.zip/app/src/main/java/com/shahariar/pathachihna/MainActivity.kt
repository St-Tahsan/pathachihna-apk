package com.shahariar.pathachihna

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.absoluteValue
import kotlin.math.max
import kotlin.math.min

private data class AppTheme(val id: String, val name: String, val accent: String, val accent2: String, val live: Boolean)
private data class Chapter(val title: String, val mark: String)
private data class ThemeAudioLayer(val player: MediaPlayer, val left: Float, val right: Float)
private data class ThemeAudioSpec(val track: String, val rate: Float, val offset: Float, val level: Float, val pan: Float)

class MainActivity : Activity() {
    private val prefs: SharedPreferences by lazy { getSharedPreferences("pathachihna_native_v1", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private lateinit var clockLabel: TextView
    private lateinit var timerLabel: TextView
    private lateinit var timerStateLabel: TextView
    private lateinit var todayStudyLabel: TextView
    private var page = "home"
    private var syllabusSubject = "physics"
    private var syllabusPaper = 1
    private var themeScope = "system"
    private var themeFilter = "live"
    private var musicPlayer: MediaPlayer? = null
    private var themePlayers = mutableListOf<ThemeAudioLayer>()
    private var outgoingThemePlayers = mutableListOf<ThemeAudioLayer>()
    private var themeMusicEnabled = true
    private var activeThemeKey = ""
    private var themeFade: Runnable? = null
    private var soundPool: SoundPool? = null
    private var decreaseSound = 0
    private var timerEndAt = 0L
    private var timerRemaining = 20 * 60
    private var focusLastTickAt = 0L
    private var pendingSeconds = 0
    private var selectedStudyTrack = "rain"
    private var musicVolume = 48
    private var introTask: Runnable? = null

    private val themes = listOf(
        AppTheme("cinejoy", "Skyline Ridge", "#56DEED", "#72A8FF", true), AppTheme("oled", "Deep OLED", "#91B7FF", "#7D88FF", false),
        AppTheme("cyberpunk", "Window Rain", "#ED97FF", "#6BE5DD", true), AppTheme("nebula", "Firefly Grove", "#FF9CB6", "#F091DF", true),
        AppTheme("emerald", "Royal Emerald", "#79EDBA", "#51C9D7", false), AppTheme("synthwave", "Evening Clouds", "#CDB2FF", "#FF8ED6", true),
        AppTheme("biolume", "Tidal Shore", "#70EBFA", "#5198FF", true), AppTheme("amethyst", "Cosmic Amethyst", "#D8ACFF", "#EE97DF", false),
        AppTheme("arctic", "Snowfall Trail", "#B8F3FF", "#779FFF", true), AppTheme("velvet", "Velvet Night", "#F4AFD2", "#C98CFF", false),
        AppTheme("lagoon", "Mountain Falls", "#68FFDA", "#5AA1FF", true), AppTheme("sapphire", "Sapphire Noir", "#9BCBFF", "#7F92FF", false),
        AppTheme("citrus", "Meadow Breeze", "#D3F774", "#76EFB4", true), AppTheme("gold", "Solar Gold", "#FFE08A", "#FFB35D", false),
        AppTheme("orion", "Starry Night", "#A8AAFF", "#6EE7FF", true), AppTheme("rouge", "Ruby Noir", "#FF9DA5", "#FF7479", false),
        AppTheme("mint", "Mint Haze", "#A1F6D8", "#70C9D4", false), AppTheme("flamingo", "Lotus Pond", "#FFB5D4", "#9A89FF", true),
        AppTheme("indigo", "Deep Indigo", "#BDB9FF", "#919DFF", false), AppTheme("coral", "Autumn Leaves", "#FFAD9B", "#F78FCF", true),
        AppTheme("jade", "Jade Lantern", "#A0EE94", "#78DCA6", false), AppTheme("moon", "Moonstone", "#B8D8F8", "#9CAEF5", false),
        AppTheme("spectral", "Desert Wind", "#E4A8FF", "#85E2FF", true), AppTheme("teal", "Deep Teal", "#83EADB", "#66BAE4", false),
        AppTheme("bamboo", "Bamboo Walk", "#B9E7A2", "#62D0B3", true), AppTheme("reef", "Coral Reef", "#7DEDED", "#FFB79D", true),
        AppTheme("lighthouse", "Lighthouse Bay", "#FDD79D", "#89C7E8", true), AppTheme("slate", "Ink Slate", "#C0CDEB", "#9DA8C9", false),
        AppTheme("copper", "Copper Dusk", "#FFBF93", "#DD937D", false), AppTheme("sage", "Sage Paper", "#CFEBBF", "#A4CDC1", false),
        AppTheme("aurora", "Aurora Drift", "#79F3DC", "#8CB4FF", true), AppTheme("glassrain", "Glasshouse Rain", "#8ACFFF", "#BCAFFF", true),
        AppTheme("quantum", "Quantum Field", "#D7A6FF", "#83EFF0", true), AppTheme("lunartide", "Lunar Tides", "#B6E0FF", "#80C5E8", true),
        AppTheme("comet", "Copper Comet", "#FFBE8F", "#E887D0", true), AppTheme("polarpulse", "Polar Pulse", "#B4F4FF", "#8CAFFF", true),
        AppTheme("ambercanyon", "Amber Canyon", "#FFCF8E", "#FF9F8E", true), AppTheme("mosslab", "Moss Observatory", "#B5E98C", "#70D7B3", true),
        AppTheme("celgarden", "Celestial Garden", "#FFC0DF", "#98D9C2", true), AppTheme("bluehour", "Blue Hour Lake", "#8BD5F6", "#93A9FF", true),
        AppTheme("solarflare", "Solar Flare", "#FFE493", "#FF9F75", true), AppTheme("quietforest", "Quiet Forest", "#B8E2A1", "#76D0B2", true)
    )

    private val physicsPapers = listOf(
        listOf(Chapter("ভেক্টর", "→"), Chapter("নিউটনীয় বলবিদ্যা", "⚛"), Chapter("কাজ, শক্তি ও ক্ষমতা", "✦"), Chapter("মহাকর্ষ ও অভিকর্ষ", "◉"), Chapter("পদার্থের গাঠনিক ধর্ম", "▦"), Chapter("পর্যায়বৃত্ত গতি", "∿"), Chapter("আদর্শ গ্যাস ও গ্যাসের গতিতত্ত্ব", "⠿")),
        listOf(Chapter("তাপগতিবিদ্যা", "♨"), Chapter("স্থির তড়িৎ", "⚡"), Chapter("চল তড়িৎ", "⌁"), Chapter("ভৌত আলোকবিজ্ঞান", "✧"), Chapter("আধুনিক পদার্থবিজ্ঞানের সূচনা", "◎"), Chapter("পরমাণুর মডেল ও নিউক্লিয়ার পদার্থবিজ্ঞান", "☼"), Chapter("সেমিকন্ডাক্টর ও ইলেকট্রনিক্স", "▥"))
    )
    private val mathPapers = listOf(
        listOf(Chapter("ম্যাট্রিক্স ও নির্ণায়ক", "▦"), Chapter("সরলরেখা", "↗"), Chapter("বৃত্ত", "◉"), Chapter("সংযুক্ত ও যৌগিক কোণের ত্রিকোণমিতিক অনুপাত", "∿"), Chapter("অন্তরীকরণ", "∂"), Chapter("যোগজীকরণ", "∫")),
        listOf(Chapter("জটিল সংখ্যা", "ℂ"), Chapter("বহুপদী ও বহুপদী সমীকরণ", "xⁿ"), Chapter("বিপরীত ত্রিকোণমিতিক ফাংশন ও ত্রিকোণমিতিক সমীকরণ", "∿"), Chapter("কণিক", "◌"), Chapter("স্থিতিবিদ্যা", "⚖"), Chapter("সমতলে বস্তুকণার গতি", "↗"))
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(11, 16, 24)
        window.navigationBarColor = Color.rgb(11, 16, 24)
        window.decorView.systemUiVisibility = 0
        musicVolume = prefs.getInt("music_volume", 48)
        selectedStudyTrack = prefs.getString("study_track", "rain") ?: "rain"
        timerRemaining = prefs.getInt("timer_remaining", 20 * 60).coerceIn(1, 52 * 60)
        timerEndAt = prefs.getLong("timer_end_at", 0L)
        themeMusicEnabled = prefs.getBoolean("theme_music", true)
        selectedStudyTrack = prefs.getString("study_track", "rain") ?: "rain"
        val pool = SoundPool.Builder().setMaxStreams(3).setAudioAttributes(
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        ).build()
        soundPool = pool
        decreaseSound = pool.load(this, R.raw.decrease, 1)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bgColor()) }
        setContentView(root)
        if (timerEndAt > System.currentTimeMillis()) {
            focusLastTickAt = System.currentTimeMillis()
            startTicker()
        } else timerEndAt = 0L
        showIntro()
    }

    private fun showIntro() {
        root.removeAllViews()
        root.gravity = Gravity.CENTER
        root.setBackgroundColor(bgColor())
        val intro = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(26), dp(24), dp(26), dp(24))
        }
        val icon = ImageView(this).apply {
            setImageResource(R.drawable.app_icon); scaleType = ImageView.ScaleType.FIT_CENTER
            alpha = 0f; translationY = dp(8).toFloat()
        }
        intro.addView(icon, LinearLayout.LayoutParams(dp(112), dp(112)))
        intro.addView(gap(16))
        val title = tv("পাঠচিহ্ন", 27f, whiteColor(), true).apply { gravity = Gravity.CENTER; alpha = 0f }
        intro.addView(title, params())
        val owner = tv("Shahariar Tahsan (St)", 12f, mutedColor()).apply { gravity = Gravity.CENTER; alpha = 0f }
        intro.addView(owner, params())
        root.addView(intro, params())
        icon.animate().alpha(1f).translationY(0f).setDuration(500).start()
        title.animate().alpha(1f).setStartDelay(180).setDuration(450).start()
        owner.animate().alpha(1f).setStartDelay(400).setDuration(450).start()
        val finish = Runnable {
            introTask = null
            root.gravity = Gravity.TOP
            renderApp()
            if (themeMusicEnabled) startThemeMusic(currentTheme().id)
        }
        introTask = finish
        handler.postDelayed(finish, 5_000L)
    }

    private fun bgColor() = Color.rgb(10, 14, 21)
    private fun panelColor() = Color.rgb(18, 25, 36)
    private fun softColor() = Color.rgb(25, 34, 47)
    private fun whiteColor() = Color.rgb(239, 244, 250)
    private fun mutedColor() = Color.rgb(159, 173, 192)
    private fun accent(): Int = try { Color.parseColor(currentTheme().accent) } catch (_: Exception) { Color.rgb(86, 222, 237) }
    private fun currentTheme(): AppTheme = themes.firstOrNull { it.id == prefs.getString("theme", "cinejoy") } ?: themes.first()
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + .5f).toInt()
    private fun params(width: Int = ViewGroup.LayoutParams.MATCH_PARENT, height: Int = ViewGroup.LayoutParams.WRAP_CONTENT) = LinearLayout.LayoutParams(width, height)
    private fun rounded(color: Int, radius: Int = 16, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); if (stroke != 0) setStroke(dp(1), stroke)
    }
    private fun tv(value: String, size: Float = 14f, color: Int = whiteColor(), bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
        includeFontPadding = true; gravity = Gravity.CENTER_VERTICAL
    }
    private fun gap(height: Int = 10) = View(this).apply { layoutParams = params(1, dp(height)) }
    private fun action(label: String, onClick: () -> Unit, selected: Boolean = false, fill: Boolean = false): TextView = tv(label, 13f, if (selected) bgColor() else whiteColor(), true).apply {
        gravity = Gravity.CENTER; setPadding(dp(12), dp(10), dp(12), dp(10)); background = rounded(if (selected) accent() else if (fill) softColor() else panelColor(), 12, if (!selected) Color.rgb(43, 57, 76) else 0)
        isAllCaps = false; setOnClickListener { onClick() }
    }
    private fun row(vararg views: View, gap: Int = 8): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        views.forEachIndexed { index, v -> val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); if (index > 0) lp.marginStart = dp(gap); addView(v, lp) }
    }
    private fun card(title: String, subtitle: String? = null, color: Int = panelColor()): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(13), dp(14), dp(13)); background = rounded(color, 16, Color.rgb(37, 49, 66))
        addView(tv(title, 14f, whiteColor(), true), params())
        if (subtitle != null) { val t = tv(subtitle, 12f, mutedColor()); val lp = params(); lp.topMargin = dp(4); addView(t, lp) }
    }
    private fun header(): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18), dp(12), dp(16), dp(12)); setBackgroundColor(Color.rgb(12, 18, 27))
        val copy = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
        copy.addView(tv("পাঠচিহ্ন", 21f, whiteColor(), true))
        copy.addView(tv("STUDY WORKSPACE", 9f, accent(), true))
        addView(copy, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val credit = tv("Shahariar Tahsan (St)", 10f, mutedColor())
        addView(credit, params(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36)))
    }

    private fun renderApp() {
        root.removeAllViews(); root.setBackgroundColor(bgColor())
        root.addView(header(), params())
        val scroll = ScrollView(this).apply { isFillViewport = true; overScrollMode = View.OVER_SCROLL_NEVER; clipToPadding = false }
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(18)) }
        body.addView(buildPage())
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(bottomNav(), params())
        body.alpha = .96f; body.translationY = dp(4).toFloat(); body.animate().alpha(1f).translationY(0f).setDuration(150).start()
    }

    private fun bottomNav(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dp(5), dp(5), dp(5), dp(7)); setBackgroundColor(Color.rgb(12, 18, 27))
        val items = listOf("home" to "⌂\nহোম", "focus" to "◷\nফোকাস", "syllabus" to "▤\nসিলেবাস", "records" to "▥\nরেকর্ড", "settings" to "⚙\nসেটিংস")
        items.forEach { (id, label) ->
            val v = tv(label, 10f, if (page == id) accent() else mutedColor(), page == id).apply {
                gravity = Gravity.CENTER; setPadding(dp(2), dp(4), dp(2), dp(2)); setOnClickListener { if (page != id) { page = id; renderApp() } }
            }
            addView(v, LinearLayout.LayoutParams(0, dp(50), 1f))
        }
    }

    private fun buildPage(): View = when (page) {
        "home" -> homePage()
        "focus" -> focusPage()
        "syllabus" -> syllabusPage()
        "records" -> recordsPage()
        else -> settingsPage()
    }

    private fun homePage(): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(tv("পরীক্ষার প্রস্তুতি", 22f, whiteColor(), true)); addView(tv("সিলেবাস, ফোকাস আর পড়ার রেকর্ড—এক জায়গায়।", 13f, mutedColor())); addView(gap(14))
        val today = todaySeconds()
        addView(row(statCard("আজকের পড়া", formatDuration(today)), statCard("ডেইলি স্ট্রিক", "${streakDays()} দিন")))
        addView(gap())
        val examCard = card("পরীক্ষার কাউন্টডাউন", "তারিখে চাপ দিয়ে বদলাও")
        examCard.addView(gap(8))
        examCard.addView(row(examButton("পদার্থবিজ্ঞান", "exam_physics", defaultExam(true)), examButton("উচ্চতর গণিত", "exam_math", defaultExam(false))))
        addView(examCard); addView(gap())
        val quick = card("দ্রুত শুরু", "")
        quick.addView(row(action("▶  ২০ মিনিট ফোকাস", { page = "focus"; renderApp() }, fill = true), action("▤  সিলেবাস", { page = "syllabus"; renderApp() }, fill = true)))
        addView(quick); addView(gap())
        val note = card("অফলাইন ও ডেটা", "পড়ার অগ্রগতি এই ফোনেই সংরক্ষিত হয়। অন্যদের সঙ্গে ডেটা শেয়ার হয় না।", Color.rgb(16, 24, 31))
        addView(note)
    }

    private fun statCard(title: String, value: String): View = card(title, value).apply {
        val lp = layoutParams as? LinearLayout.LayoutParams
        lp?.let { it.height = dp(82); layoutParams = it }
    }

    private fun defaultExam(physics: Boolean): Long {
        val key = if (physics) "exam_physics" else "exam_math"
        val default = Calendar.getInstance().apply { set(2026, if (physics) Calendar.DECEMBER else Calendar.DECEMBER, if (physics) 3 else 8, 0, 0, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
        return prefs.getLong(key, default)
    }

    private fun examButton(title: String, prefKey: String, whenMs: Long): View {
        val today = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
        val days = ((whenMs - today) / 86_400_000L).toInt()
        val date = SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(whenMs))
        return action("$title\n$date\n${if (days >= 0) "$days দিন বাকি" else "তারিখ পেরিয়েছে"}", {
            val c = Calendar.getInstance().apply { timeInMillis = whenMs }
            DatePickerDialog(this, { _, year, month, day ->
                val chosen = Calendar.getInstance().apply { set(year, month, day, 0, 0, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
                prefs.edit().putLong(prefKey, chosen).apply(); renderApp()
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
        }, fill = true).apply { textSize = 11.5f; minHeight = dp(76) }
    }

    private fun focusPage(): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(tv("ফোকাস টাইমার", 22f, whiteColor(), true)); addView(tv("টাইমার চললে পড়ার সময় নিজে থেকে রেকর্ড হবে।", 12f, mutedColor())); addView(gap())
        addView(row(action("পদার্থবিজ্ঞান", { prefs.edit().putString("focus_subject", "physics").apply(); renderApp() }, prefs.getString("focus_subject", "physics") == "physics"), action("উচ্চতর গণিত", { prefs.edit().putString("focus_subject", "math").apply(); renderApp() }, prefs.getString("focus_subject", "physics") == "math")))
        addView(gap(7))
        addView(row(action("১ম পত্র", { prefs.edit().putInt("focus_paper", 1).apply(); renderApp() }, prefs.getInt("focus_paper", 1) == 1), action("২য় পত্র", { prefs.edit().putInt("focus_paper", 2).apply(); renderApp() }, prefs.getInt("focus_paper", 1) == 2)))
        addView(gap())
        val timerCard = card("সেশন", "২০ মিনিট ফোকাস মোড")
        timerCard.addView(gap(12))
        timerLabel = tv(formatTimer(timerRemaining), 42f, accent(), true).apply { gravity = Gravity.CENTER; typeface = Typeface.create("sans-serif-medium", Typeface.BOLD) }
        timerCard.addView(timerLabel, params())
        timerStateLabel = tv(if (timerEndAt > 0) "চলছে" else "প্রস্তুত", 12f, mutedColor()).apply { gravity = Gravity.CENTER }
        timerCard.addView(timerStateLabel, params())
        timerCard.addView(gap(12))
        timerCard.addView(row(action(if (timerEndAt > 0) "Ⅱ  বিরতি" else "▶  শুরু", { if (timerEndAt > 0) pauseTimer() else startTimer() }, selected = true), action("↺  রিসেট", { resetTimer() }, fill = true)))
        addView(timerCard); addView(gap())
        val musicCard = card("স্টাডি মিউজিক", "অফলাইন · আলাদা player")
        musicCard.addView(gap(8))
        listOf("rain" to "বৃষ্টির জানালা", "river" to "নদীর হাওয়া", "piano" to "নীরব পিয়ানো", "stars" to "তারাভরা রাত", "forest" to "বনের সকাল", "deep" to "গভীর মনোযোগ").forEach { (id, name) ->
            musicCard.addView(action("${if (selectedStudyTrack == id) "●" else "○"}  $name", { selectedStudyTrack = id; prefs.edit().putString("study_track", id).apply(); playStudyTrack(id); renderApp() }, selected = selectedStudyTrack == id, fill = true), params().apply { topMargin = dp(5) })
        }
        musicCard.addView(gap(5))
        musicCard.addView(action(if (musicPlayer?.isPlaying == true) "Ⅱ  মিউজিক বিরতি" else "▶  মিউজিক চালু", { if (musicPlayer?.isPlaying == true) stopStudyMusic() else playStudyTrack(selectedStudyTrack); renderApp() }, fill = true))
        val volume = SeekBar(this@MainActivity).apply { max = 100; progress = musicVolume; setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { if (fromUser) { musicVolume = progress; prefs.edit().putInt("music_volume", progress).apply(); musicPlayer?.setVolume(progress / 100f, progress / 100f) } }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }) }
        musicCard.addView(volume, params()); addView(musicCard)
    }

    private fun startTicker() {
        handler.removeCallbacks(timerTask)
        handler.post(timerTask)
    }

    private fun startTimer() {
        if (timerRemaining <= 0) timerRemaining = 20 * 60
        timerEndAt = System.currentTimeMillis() + timerRemaining * 1000L
        focusLastTickAt = System.currentTimeMillis()
        prefs.edit().putLong("timer_end_at", timerEndAt).putInt("timer_remaining", timerRemaining).apply()
        handler.removeCallbacks(timerTask); handler.post(timerTask); renderApp()
    }
    private fun pauseTimer() {
        val now = System.currentTimeMillis()
        if (timerEndAt > 0) timerRemaining = max(0, ((timerEndAt - now + 999) / 1000).toInt())
        addFocusedTime(now)
        timerEndAt = 0L; prefs.edit().putLong("timer_end_at", 0L).putInt("timer_remaining", timerRemaining).apply()
        handler.removeCallbacks(timerTask); renderApp()
    }
    private fun resetTimer() {
        if (timerEndAt > 0) pauseTimer()
        timerRemaining = 20 * 60; timerEndAt = 0L; focusLastTickAt = 0L
        prefs.edit().putLong("timer_end_at", 0L).putInt("timer_remaining", timerRemaining).apply(); renderApp()
    }
    private fun addFocusedTime(now: Long) {
        if (focusLastTickAt > 0L) {
            val seconds = ((now - focusLastTickAt) / 1000L).toInt().coerceAtLeast(0)
            if (seconds > 0) { pendingSeconds += seconds; focusLastTickAt = now }
        }
        if (pendingSeconds > 0) { addStudySeconds(pendingSeconds); pendingSeconds = 0 }
    }
    private val timerTask = object : Runnable {
        override fun run() {
            if (timerEndAt <= 0L) return
            val now = System.currentTimeMillis(); addFocusedTime(now)
            timerRemaining = max(0, ((timerEndAt - now + 999) / 1000L).toInt())
            if (::timerLabel.isInitialized) timerLabel.text = formatTimer(timerRemaining)
            if (::timerStateLabel.isInitialized) timerStateLabel.text = "চলছে · আজ ${formatDuration(todaySeconds())}"
            prefs.edit().putInt("timer_remaining", timerRemaining).apply()
            if (timerRemaining <= 0) {
                timerEndAt = 0L; prefs.edit().putLong("timer_end_at", 0L).apply()
                Toast.makeText(this@MainActivity, "ফোকাস সেশন শেষ · পড়ার সময় সেভ হয়েছে", Toast.LENGTH_LONG).show()
                renderApp()
            } else handler.postDelayed(this, 1000L)
        }
    }
    private fun formatTimer(seconds: Int): String = String.format(Locale.getDefault(), "%02d:%02d", seconds / 60, seconds % 60)
    private fun formatDuration(seconds: Int): String = if (seconds < 3600) "${seconds / 60} মি" else "${seconds / 3600} ঘ ${seconds % 3600 / 60} মি"

    private fun syllabusPage(): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(tv("সিলেবাস", 22f, whiteColor(), true)); addView(tv("প্রতিটি অধ্যায়ের নিজস্ব রঙ ও চেকপয়েন্ট।", 12f, mutedColor())); addView(gap())
        addView(row(action("পদার্থবিজ্ঞান", { syllabusSubject = "physics"; renderApp() }, syllabusSubject == "physics"), action("উচ্চতর গণিত", { syllabusSubject = "math"; renderApp() }, syllabusSubject == "math")))
        addView(gap(7))
        addView(row(action("১ম পত্র", { syllabusPaper = 1; renderApp() }, syllabusPaper == 1), action("২য় পত্র", { syllabusPaper = 2; renderApp() }, syllabusPaper == 2)))
        val chapters = if (syllabusSubject == "physics") physicsPapers[syllabusPaper - 1] else mathPapers[syllabusPaper - 1]
        val cpNames = if (syllabusSubject == "physics") listOf("ক", "খ", "MCQ", "CQ") else listOf("ক", "MCQ", "CQ")
        val done = readCheckpointSet(); val total = chapters.size * cpNames.size; val checked = chapters.sumOf { ch -> cpNames.count { cp -> "${syllabusSubject}_${syllabusPaper}_${ch.title}_$cp" in done } }
        addView(gap(10)); addView(card("এই পত্রের অগ্রগতি", "$checked / $total চেকপয়েন্ট · ${if (total > 0) checked * 100 / total else 0}%"))
        addView(gap(9))
        chapters.forEachIndexed { index, chapter ->
            addView(chapterCard(chapter, index, cpNames, done))
            addView(gap(7))
        }
    }

    private fun chapterCard(chapter: Chapter, index: Int, cpNames: List<String>, done: MutableSet<String>): View {
        val hue = (chapter.title.hashCode().absoluteValue % 360)
        val selectedStyleId = prefs.getString("subject_theme_$syllabusSubject", "")
        val selectedStyle = subjectThemeCards(syllabusSubject).firstOrNull { it.id == selectedStyleId }
        val tint = selectedStyle?.let { Color.parseColor(if (index % 2 == 0) it.accent else it.accent2) }
            ?: Color.HSVToColor(floatArrayOf(hue.toFloat(), .56f, .95f))
        val section = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10)); background = rounded(Color.rgb(17, 24, 35), 14, tint) }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("${(index + 1).toString().padStart(2, '0')}  ${chapter.mark}", 12f, tint, true), LinearLayout.LayoutParams(dp(56), ViewGroup.LayoutParams.WRAP_CONTENT))
        val title = tv(chapter.title, 13.5f, whiteColor(), true); head.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val percent = tv("", 12f, tint, true); head.addView(percent, params(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)); section.addView(head)
        val keyFor = { cp: String -> "${syllabusSubject}_${syllabusPaper}_${chapter.title}_$cp" }
        val cpRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, 0) }
        val checkButtons = mutableListOf<Pair<String, TextView>>()
        cpNames.forEachIndexed { buttonIndex, cp ->
            val key = keyFor(cp); val button = action("${if (key in done) "✓ " else "○ "}$cp", {
                if (key in done) done.remove(key) else done.add(key)
                prefs.edit().putStringSet("checkpoints", done.toSet()).apply()
                checkButtons.forEach { (k, v) ->
                    val marked = k in done; v.text = "${if (marked) "✓ " else "○ "}${k.substringAfterLast('_')}"; v.setTextColor(if (marked) bgColor() else mutedColor()); v.background = rounded(if (marked) tint else softColor(), 10)
                }
                val count = cpNames.count { keyFor(it) in done }; percent.text = "${count * 100 / cpNames.size}%"
                try { soundPool?.play(decreaseSound, .75f, .75f, 1, 0, 1f) } catch (_: Exception) {}
            }, selected = key in done, fill = true).apply { textSize = 11.5f; minHeight = dp(38) }
            val lp = LinearLayout.LayoutParams(0, dp(37), 1f); if (buttonIndex > 0) lp.marginStart = dp(5); cpRow.addView(button, lp); checkButtons.add(key to button)
        }
        section.addView(cpRow)
        val count = cpNames.count { keyFor(it) in done }; percent.text = "${count * 100 / cpNames.size}%"
        return section
    }

    private fun recordsPage(): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        val total = todaySeconds()
        addView(tv("পড়ার রেকর্ড", 22f, whiteColor(), true)); addView(tv("আজকের সেশন এই ফোনে অটো-সেভ হয়।", 12f, mutedColor())); addView(gap())
        addView(row(statCard("আজকের পড়া", formatDuration(total)), statCard("ডেইলি লক্ষ্য", "৮ ঘণ্টা")))
        addView(gap())
        val history = card("গত ৭ দিন", "প্রতিদিনের পড়ার সময়")
        history.addView(gap(8))
        for (i in 0..6) {
            val date = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -i) }
            val key = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(date.time)
            val seconds = prefs.getInt("study_$key", 0)
            history.addView(row(tv(SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(date.time), 12f, mutedColor()), tv(formatDuration(seconds), 12f, if (seconds >= 8 * 3600) accent() else whiteColor(), true)))
            if (i < 6) history.addView(gap(7))
        }
        addView(history); addView(gap())
        addView(action("ডেটা ব্যাকআপ নিন", { exportBackup() }, fill = true)); addView(gap(6)); addView(action("ব্যাকআপ ফিরিয়ে আনুন", { importBackup() }, fill = true))
    }

    private fun settingsPage(): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(tv("সেটিংস", 22f, whiteColor(), true)); addView(tv("হালকা native UI · ডেটা এই ফোনেই থাকে।", 12f, mutedColor())); addView(gap())
        addView(tv("থিমের music", 12f, mutedColor(), true))
        addView(gap(4))
        addView(action(if (themeMusicEnabled) "♫" else "🔇", { toggleThemeMusic() }, selected = themeMusicEnabled).apply { textSize = 18f; minHeight = dp(42) })
        addView(gap())
        addView(row(action("সিস্টেম", { themeScope = "system"; renderApp() }, themeScope == "system"), action("পদার্থবিজ্ঞান", { themeScope = "physics"; renderApp() }, themeScope == "physics"), action("উচ্চতর গণিত", { themeScope = "math"; renderApp() }, themeScope == "math")))
        addView(gap(7))
        if (themeScope == "system") addView(row(action("লাইভ", { themeFilter = "live"; renderApp() }, themeFilter == "live"), action("স্থির", { themeFilter = "still"; renderApp() }, themeFilter == "still")))
        val available: List<AppTheme> = if (themeScope == "system") themes.filter { it.live == (themeFilter == "live") } else subjectThemeCards(themeScope)
        val grid = GridLayout(this@MainActivity).apply { columnCount = 2; useDefaultMargins = false; alignmentMode = GridLayout.ALIGN_BOUNDS }
        available.forEach { theme ->
            val selected = if (themeScope == "system") currentTheme().id == theme.id else prefs.getString("subject_theme_$themeScope", "") == theme.id
            val tile = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(11), dp(9), dp(11)); background = rounded(panelColor(), 13, if (selected) accent() else Color.rgb(41, 53, 69)); minimumHeight = dp(67)
                addView(tv("●  ${theme.name}", 12f, Color.parseColor(theme.accent), true))
                addView(tv(if (theme.live) "LIVE" else "STATIC", 9f, mutedColor()))
                setOnClickListener {
                    if (themeScope == "system") {
                        prefs.edit().putString("theme", theme.id).apply()
                        if (themeMusicEnabled) startThemeMusic(theme.id)
                    } else prefs.edit().putString("subject_theme_$themeScope", theme.id).apply()
                    renderApp()
                }
            }
            val lp = GridLayout.LayoutParams().apply { width = 0; height = dp(68); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(dp(3), dp(3), dp(3), dp(3)) }
            grid.addView(tile, lp)
        }
        addView(grid); addView(gap())
        val musicCard = card("স্টাডি music", "Study music control শুধু Focus page-এ।")
        musicCard.addView(action("Focus page খুলুন", { page = "focus"; renderApp() }, fill = true)); addView(musicCard); addView(gap())
        addView(card("ডেটা", "ব্যাকআপ, রিস্টোর এবং ডিভাইস-ভিত্তিক সেভিংস Records page-এ।")); addView(gap())
        addView(action("সব পড়ার ডেটা রিসেট", { AlertDialog.Builder(this@MainActivity).setTitle("সব ডেটা মুছবেন?").setMessage("এই ফোনের সেভ করা checkpoint ও study record মুছে যাবে।").setNegativeButton("Cancel", null).setPositiveButton("Reset") { _, _ -> prefs.edit().clear().apply(); timerEndAt = 0L; timerRemaining = 1200; stopAllMusic(); renderApp() }.show() }, fill = true))
    }

    private fun subjectThemeCards(scope: String): List<AppTheme> {
        val colors = if (scope == "physics") listOf("#57BCD9", "#4DDDCF", "#7CDDF5", "#BF93FF", "#8DDBFF", "#9BA9FF", "#74D3D7", "#DBC69B", "#A3A9FB") else listOf("#CF95EB", "#FFAC83", "#73CCBC", "#A5A8F1", "#99D4A6", "#EF98C6", "#CE9DE6", "#9AE1EB", "#E5A9CF")
        val names = if (scope == "physics") listOf("Blue Orbit", "Wave Tank", "Prism Light", "Magnetic Field", "Photon Paths", "Star Atlas", "Particle Trails", "Pendulum Lab", "Gravity Well") else listOf("Contour Lines", "Fibonacci Spiral", "Geometric Mosaic", "Vector Flow", "Fractal Garden", "Locus Lines", "Pascal Grid", "Lissajous Loop", "Topology Rings")
        return names.indices.map { i -> AppTheme("${scope}_$i", names[i], colors[i], colors[(i + 2) % colors.size], true) }
    }

    private fun toggleThemeMusic() {
        themeMusicEnabled = !themeMusicEnabled; prefs.edit().putBoolean("theme_music", themeMusicEnabled).apply()
        if (themeMusicEnabled) startThemeMusic(currentTheme().id) else stopThemeMusic()
        renderApp()
    }
    private fun primaryThemeTrack(themeId: String): String = when (themeId) {
        "cinejoy", "synthwave", "orion", "sapphire", "indigo", "aurora" -> "stars"
        "oled", "rouge", "slate", "quantum" -> "deep"
        "cyberpunk", "arctic", "coral", "spectral", "lighthouse", "glassrain", "polarpulse" -> "rain"
        "nebula", "citrus", "mint", "jade", "bamboo", "sage", "mosslab", "celgarden", "quietforest" -> "forest"
        "emerald", "biolume", "lagoon", "flamingo", "teal", "reef", "lunartide", "ambercanyon", "bluehour" -> "river"
        else -> "piano"
    }
    private fun themeArrangement(themeId: String): List<ThemeAudioSpec> {
        val tracks = listOf("rain", "river", "piano", "stars", "forest", "deep")
        var seed = 2_166_136_261L
        "system:$themeId".forEach { ch -> seed = ((seed xor ch.code.toLong()) * 16_777_619L) and 0xffffffffL }
        if (seed == 0L) seed = 173L
        val primary = primaryThemeTrack(themeId)
        val remaining = tracks.filter { it != primary }
        val second = remaining[((seed shr 5) % remaining.size).toInt()]
        val chosen = mutableListOf(primary, second)
        if ((seed and 3L) == 1L) {
            val rest = tracks.filterNot { it in chosen }
            chosen.add(rest[((seed shr 11) % rest.size).toInt()])
        }
        return chosen.mapIndexed { i, track ->
            val bits = (seed shr (i * 7)) and 255L
            val variant = (seed shr (i * 5 + 3)) and 255L
            seed = ((seed xor 0x9e3779b9L) * 1_664_525L) and 0xffffffffL
            ThemeAudioSpec(track, .86f + bits / 255f * .30f, variant / 255f * .76f,
                when (i) { 0 -> .22f; 1 -> .14f; else -> .08f }, when (i) { 0 -> -.22f; 1 -> .22f; else -> .06f })
        }
    }
    private fun startThemeMusic(themeId: String) {
        if (!themeMusicEnabled) return
        if (activeThemeKey == themeId && themePlayers.any { try { it.player.isPlaying } catch (_: Exception) { false } }) return
        themeFade?.let(handler::removeCallbacks); themeFade = null
        outgoingThemePlayers.forEach { layer -> try { layer.player.stop(); layer.player.release() } catch (_: Exception) {} }
        outgoingThemePlayers = themePlayers
        val specs = themeArrangement(themeId)
        val nextLayers = mutableListOf<ThemeAudioLayer>()
        specs.forEach { spec ->
            val player = try { MediaPlayer.create(this, trackResource(spec.track)) } catch (_: Exception) { null }
            if (player != null) {
                try {
                    player.isLooping = true
                    if (android.os.Build.VERSION.SDK_INT >= 23) player.playbackParams = player.playbackParams.setSpeed(spec.rate)
                    if (player.duration > 0) player.seekTo((player.duration * spec.offset).toInt())
                    val left = spec.level * (1f - max(0f, spec.pan))
                    val right = spec.level * (1f + min(0f, spec.pan))
                    player.setVolume(0f, 0f); player.start()
                    nextLayers.add(ThemeAudioLayer(player, left, right))
                } catch (_: Exception) { try { player.release() } catch (_: Exception) {} }
            }
        }
        if (nextLayers.isEmpty()) return
        themePlayers = nextLayers; activeThemeKey = themeId
        var step = 0
        val old = outgoingThemePlayers.toList()
        val fade = object : Runnable {
            override fun run() {
                step++
                val p = min(1f, step / 16f)
                nextLayers.forEach { layer -> try { layer.player.setVolume(layer.left * p, layer.right * p) } catch (_: Exception) {} }
                old.forEach { layer -> try { layer.player.setVolume(layer.left * (1f - p), layer.right * (1f - p)) } catch (_: Exception) {} }
                if (p < 1f) handler.postDelayed(this, 45L) else {
                    old.forEach { layer -> try { layer.player.stop(); layer.player.release() } catch (_: Exception) {} }
                    outgoingThemePlayers = mutableListOf()
                    themeFade = null
                }
            }
        }
        themeFade = fade; handler.post(fade)
    }
    private fun stopThemeMusic() {
        themeFade?.let(handler::removeCallbacks); themeFade = null
        (themePlayers + outgoingThemePlayers).forEach { layer -> try { layer.player.stop(); layer.player.release() } catch (_: Exception) {} }
        themePlayers.clear(); outgoingThemePlayers.clear(); activeThemeKey = ""
    }
    private fun trackResource(id: String): Int = when (id) {
        "rain" -> R.raw.rain; "river" -> R.raw.river; "piano" -> R.raw.piano; "stars" -> R.raw.stars; "forest" -> R.raw.forest; else -> R.raw.deep
    }
    private fun playStudyTrack(id: String) {
        stopStudyMusic(); selectedStudyTrack = id
        val player = try { MediaPlayer.create(this, trackResource(id)) } catch (_: Exception) { null } ?: return
        player.isLooping = true; player.setVolume(musicVolume / 100f, musicVolume / 100f); player.start(); musicPlayer = player
    }
    private fun stopStudyMusic() { try { musicPlayer?.stop(); musicPlayer?.release() } catch (_: Exception) {}; musicPlayer = null }
    private fun stopAllMusic() { stopStudyMusic(); stopThemeMusic() }

    private fun readCheckpointSet(): MutableSet<String> = prefs.getStringSet("checkpoints", emptySet())?.toMutableSet() ?: mutableSetOf()
    private fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private fun todaySeconds(): Int = prefs.getInt("study_${todayKey()}", 0)
    private fun addStudySeconds(seconds: Int) {
        if (seconds <= 0) return
        val key = "study_${todayKey()}"; prefs.edit().putInt(key, prefs.getInt(key, 0) + seconds).apply()
    }
    private fun streakDays(): Int {
        var count = 0
        val c = Calendar.getInstance()
        for (i in 0..365) {
            val key = "study_${SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.time)}"
            if (prefs.getInt(key, 0) >= 8 * 3600) { count++; c.add(Calendar.DAY_OF_YEAR, -1) } else break
        }
        return count
    }

    private fun exportBackup() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"; putExtra(Intent.EXTRA_TITLE, "pathachihna-backup.json") }
        try { startActivityForResult(intent, 1001) } catch (_: Exception) { Toast.makeText(this, "File picker খোলা যায়নি", Toast.LENGTH_SHORT).show() }
    }
    private fun importBackup() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json" }
        try { startActivityForResult(intent, 1002) } catch (_: Exception) { Toast.makeText(this, "File picker খোলা যায়নি", Toast.LENGTH_SHORT).show() }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        try {
            if (requestCode == 1001) {
                val json = JSONObject()
                prefs.all.forEach { (key, value) -> when (value) {
                    is String -> json.put(key, value)
                    is Boolean -> json.put(key, value)
                    is Int -> json.put(key, value)
                    is Long -> json.put(key, value)
                    is Float -> json.put(key, value.toDouble())
                    is Set<*> -> json.put(key, org.json.JSONArray(value.toList()))
                } }
                contentResolver.openOutputStream(uri)?.use { it.write(json.toString(2).toByteArray(Charsets.UTF_8)) }
                Toast.makeText(this, "Backup সেভ হয়েছে", Toast.LENGTH_SHORT).show()
            } else if (requestCode == 1002) {
                val raw = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: return
                val json = JSONObject(raw); val editor = prefs.edit()
                val keys = json.keys()
                while (keys.hasNext()) {
                    val key = keys.next(); val value = json.get(key)
                    when (value) {
                        is Boolean -> editor.putBoolean(key, value)
                        is Int -> editor.putInt(key, value)
                        is Long -> editor.putLong(key, value)
                        is Double -> editor.putFloat(key, value.toFloat())
                        is String -> editor.putString(key, value)
                        is org.json.JSONArray -> { val set = mutableSetOf<String>(); for (i in 0 until value.length()) set.add(value.getString(i)); editor.putStringSet(key, set) }
                    }
                }
                editor.apply(); themeMusicEnabled = prefs.getBoolean("theme_music", true); renderApp(); Toast.makeText(this, "Backup ফিরেছে", Toast.LENGTH_SHORT).show()
            }
        } catch (_: Exception) { Toast.makeText(this, "Backup ফাইলটি পড়া যায়নি", Toast.LENGTH_LONG).show() }
    }

    override fun onPause() {
        if (timerEndAt > 0) addFocusedTime(System.currentTimeMillis())
        super.onPause()
    }
    override fun onDestroy() {
        handler.removeCallbacks(timerTask)
        introTask?.let(handler::removeCallbacks); introTask = null
        stopAllMusic(); soundPool?.release(); soundPool = null
        super.onDestroy()
    }
}

