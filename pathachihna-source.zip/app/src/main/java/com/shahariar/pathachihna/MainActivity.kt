package com.shahariar.pathachihna

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.webkit.ServiceWorkerClientCompat
import androidx.webkit.ServiceWorkerControllerCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewFeature
import java.io.IOException

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var assetLoader: WebViewAssetLoader
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private var pendingBackupJson: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(10, 14, 21)
        window.navigationBarColor = android.graphics.Color.rgb(10, 14, 21)
        window.decorView.setBackgroundColor(android.graphics.Color.rgb(10, 14, 21))

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        if (WebViewFeature.isFeatureSupported(WebViewFeature.SERVICE_WORKER_BASIC_USAGE)) {
            ServiceWorkerControllerCompat.getInstance().setServiceWorkerClient(object : ServiceWorkerClientCompat() {
                override fun shouldInterceptRequest(request: WebResourceRequest): WebResourceResponse? =
                    assetLoader.shouldInterceptRequest(request.url)
            })
        }

        webView = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(10, 14, 21))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = false
            settings.textZoom = 100
            addJavascriptInterface(NativeBridge(), "PathachihnaNative")
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest): WebResourceResponse? =
                    assetLoader.shouldInterceptRequest(request.url)

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest): Boolean {
                    val uri = request.url
                    if (uri.host == "appassets.androidplatform.net") return false
                    openExternal(uri)
                    return true
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    view: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    this@MainActivity.fileChooserCallback?.onReceiveValue(null)
                    this@MainActivity.fileChooserCallback = filePathCallback
                    val intent = try {
                        fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "application/json"
                        }
                    } catch (_: Exception) {
                        Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "application/json"
                        }
                    }
                    return try {
                        startActivityForResult(intent, REQUEST_PICK_FILE)
                        true
                    } catch (_: Exception) {
                        this@MainActivity.fileChooserCallback?.onReceiveValue(null)
                        this@MainActivity.fileChooserCallback = null
                        Toast.makeText(this@MainActivity, "ফাইল বাছাই খোলা যায়নি", Toast.LENGTH_SHORT).show()
                        false
                    }
                }
            }
        }

        setContentView(FrameLayout(this).apply {
            addView(webView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        })
        if (savedInstanceState == null) {
            webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    private inner class NativeBridge {
        @JavascriptInterface
        fun saveBackup(json: String) {
            runOnUiThread {
                pendingBackupJson = json
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "pathachihna-backup.json")
                }
                try {
                    startActivityForResult(intent, REQUEST_SAVE_BACKUP)
                } catch (_: Exception) {
                    pendingBackupJson = null
                    Toast.makeText(this@MainActivity, "ফাইল সেভ করা যায়নি", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun openExternal(uri: Uri) {
        if (uri.scheme == "https" || uri.scheme == "http" || uri.scheme == "mailto") {
            try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) {
                Toast.makeText(this, "লিংকটি খোলা যায়নি", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @Deprecated("Uses document picker result for WebView backup and restore")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_PICK_FILE) {
            val callback = fileChooserCallback
            fileChooserCallback = null
            val result = if (resultCode == RESULT_OK && data?.data != null) arrayOf(data.data!!) else null
            callback?.onReceiveValue(result)
            return
        }
        if (requestCode == REQUEST_SAVE_BACKUP) {
            val json = pendingBackupJson
            pendingBackupJson = null
            if (resultCode != RESULT_OK || data?.data == null || json == null) return
            try {
                contentResolver.openOutputStream(data.data!!)?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                Toast.makeText(this, "Backup সেভ হয়েছে", Toast.LENGTH_SHORT).show()
            } catch (_: IOException) {
                Toast.makeText(this, "Backup সেভ করা যায়নি", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        if (::webView.isInitialized) webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Use device back navigation")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            fileChooserCallback?.onReceiveValue(null)
            fileChooserCallback = null
            webView.stopLoading()
            webView.removeJavascriptInterface("PathachihnaNative")
            webView.destroy()
        }
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_PICK_FILE = 401
        private const val REQUEST_SAVE_BACKUP = 402
    }
}
