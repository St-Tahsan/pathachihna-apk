# Keep the application small without shrinking; no custom keep rules are required.
