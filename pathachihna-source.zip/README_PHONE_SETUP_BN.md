# পাঠচিহ্ন Native APK — ফোন থেকে ফ্রি build

এটি Kotlin native Android source project। এই ZIP নিজে APK নয়। GitHub Actions-এ build শেষ হলে APK-টি `app-debug.apk` নামে artifact হিসেবে নামানো যাবে। Android-এ ইনস্টল করার আগে download করা APK খুলে Install দিন; Play Protect confirmation চাইলে ফাইলটি আপনার নিজের build কিনা যাচাই করে এগোন।

## একবারের setup (Android ফোন থেকেই)

1. GitHub account-এ সাইন ইন করে একটি **Public** repository তৈরি করুন, যেমন `pathachihna-apk`। Public রাখলে GitHub Actions-এর free minutes ব্যবহার করা যায়।
2. এই project-এর ZIP-টি repository root-এ ঠিক `pathachihna-source.zip` নামে upload/commit করুন। ZIP খুলবেন না—ZIP-টি যেমন আছে তেমনই রাখুন।
3. GitHub-এ **Add file → Create new file** বেছে নিয়ে filename হিসেবে `.github/workflows/android.yml` লিখুন। এই project's `.github/workflows/android.yml` ফাইলের সব লেখা কপি করে GitHub editor-এ paste করে **Commit changes** দিন।
4. Repository-তে **Actions** tab → **Build Pathachihna APK** workflow → **Run workflow** → **Run workflow** চাপুন.
5. Workflow run-টি `✓` হওয়া পর্যন্ত অপেক্ষা করুন। Run খুলে **Artifacts → Pathachihna-debug-APK** ডাউনলোড করুন; ZIP artifact-টি ফোনে extract করে `app-debug.apk` খুলুন.
6. APK অন্য কারও সাথে পাঠাতে পারেন। অন্য Android ফোনে install করার সময় ওই ফোনের “Install unknown apps” অনুমতি দিতে হতে পারে.

## Build fail হলে

Actions run খুলে লাল failed step-এর log দেখুন। `Upload pathachihna-source.zip` দেখালে ZIP-টি repository root-এ এবং সঠিক নামে আছে কি না যাচাই করুন। SDK/Gradle error হলে log-টা project maintainer-কে পাঠান.

## Build-এပါ থাকা

App source, Android Gradle config, existing app icon, app audio assets, native Kotlin screens, and the GitHub Actions workflow. Buildটি debug-signed APK তৈরি করে; এটি Play Store release নয়।
