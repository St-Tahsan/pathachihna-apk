# পাঠচিহ্ন Android APK — ফোন থেকে GitHub Actions build

এই project-এ পাঠচিহ্নের মূল HTML/CSS/JavaScript app এবং প্রয়োজনীয় assets APK-র ভেতরে bundled থাকে। Android app-টি WebView ব্যবহার করে bundled app চালায়, তাই মূল UI ও web app feature-গুলোই থাকে; app খুলতে hosted site লাগবে না। এই ZIP নিজে APK নয়। GitHub Actions build শেষ হলে `app-debug.apk` artifact পাওয়া যাবে।

## GitHub build (ফোন থেকে)

1. GitHub-এ একটি **Public** repository তৈরি করুন।
2. এই project ZIP-টি repository root-এ ঠিক `pathachihna-source.zip` নামে upload/commit করুন। ZIP খুলবেন না।
3. `.github/workflows/android.yml` workflow file repository-তে রাখুন; workflow-টি root-level ZIP unpack করে `assembleDebug` চালায়।
4. **Actions** tab থেকে `Build Pathachihna APK` run-এর সবুজ ✓ অপেক্ষা করুন।
5. Run page-এর **Artifacts** থেকে `Pathachihna-debug-APK` ZIP download করে extract করুন; তার ভেতরের `app-debug.apk` install করুন।

## APK install ও share

Android যদি “Install unknown apps” অনুমতি চায়, ফাইল app/Brave-কে অনুমতি দিয়ে install চালিয়ে যান। APK-টি অন্য Android phone-এও পাঠানো যাবে। Debug build-টি Play Store release নয়।

## App details

- Original app icon, Bengali UI, silent five-second intro, CSS themes, calendar, study timer, music and records bundled locally.
- Backup export native Android document picker-এ JSON save করে; restore Android document picker দিয়ে file বেছে নেয়.
- GitHub Actions uses Android SDK 35, Gradle 8.9 and Java 17.
- Creator attribution: `Shahariar Tahsan (St)`.
